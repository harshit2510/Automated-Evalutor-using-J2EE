

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class showtopic
 */
@WebServlet("/showtopic")
public class showtopic extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public showtopic() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter pw=response.getWriter();
		
		try
		{
			String str1=request.getParameter("subject");
			String str2=request.getParameter("teacher");
			Class.forName("com.mysql.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/evaluator?user=root&password=adminadmin");	
		
			
     		String str6="select distinct(topic) from teacher where subject='"+str1+"' && name='"+str2+"'";
			    		  PreparedStatement st1=cn.prepareStatement(str6);
			    		 
			    		  ResultSet rs=st1.executeQuery();
						  String data="";
						  
						   while(rs.next()){
							  
							   data=data+"<option>"+rs.getString(1)+"</option>";
						   }	   
							pw.println(data); 
			    		  	
			    }
			   
	catch(Exception e)
		{
		pw.println(e.getMessage());
		
		
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
