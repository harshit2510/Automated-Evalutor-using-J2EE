

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class submit
 */
@WebServlet("/submit")
public class submit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public submit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter pw=response.getWriter();
		
		try
		{
			String str=request.getParameter("id");
		String str1=request.getParameter("subject");
		String str2=request.getParameter("teacher");
		String str3=request.getParameter("topic");
		String str4=request.getParameter("question");
		String str5=request.getParameter("answer");
		String str6="";
		String str9="";
		Class.forName("com.mysql.jdbc.Driver");
		Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/evaluator?user=root&password=adminadmin");	
	
            String str7="Select distinct(id) from teacher where name='"+str2+"'";
            String str8="Select distinct(name) from user where id='"+str+"'";
            PreparedStatement st=cn.prepareStatement(str7);
		    PreparedStatement st1=cn.prepareStatement(str8);
		    
		    ResultSet rs=st.executeQuery();
		    ResultSet rs1=st1.executeQuery();
		    while(rs.next()){
		    	str6=rs.getString(1);
		    }
		    
while(rs1.next()){

		    	str9=rs1.getString(1);
		    	
		    	
		    	
		    }
String str10="Insert into qa values(?,?,?,?,?,?,?)";
PreparedStatement st2=cn.prepareStatement(str10);
st2.setString(1,str);
st2.setString(2,str9); 
st2.setString(3,str6);
st2.setString(4,str1);
st2.setString(5,str3);
st2.setString(6,str4);
st2.setString(7,str5);
st2.executeUpdate();

		
	}
		catch(Exception e)
		{
		pw.println(e.getMessage());
		
		
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
