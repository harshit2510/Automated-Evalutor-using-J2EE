

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Addquestion
 */
@WebServlet("/Addquestion")
public class Addquestion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Addquestion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter pw=response.getWriter();
		
		try
		{
			String str1=request.getParameter("id");
			String str2=request.getParameter("subject");
			String str3=request.getParameter("topic");
			String str4=request.getParameter("question");
			String str5=request.getParameter("answer");
			Class.forName("com.mysql.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/evaluator?user=root&password=adminadmin");	
     		String str7="Select * from user where id='"+str1+"'";
     		PreparedStatement st2=cn.prepareStatement(str7);
   		 
  		  ResultSet rs=st2.executeQuery();
  		  String str8="";
  		  while(rs.next())
  		  {
  			  str8=rs.getString(3);
  			  
  			  
  		  }
			String str6="Insert into teacher values(?,?,?,?,?,?)";
			    		  PreparedStatement st1=cn.prepareStatement(str6);
			    		  st1.setString(1,str1);
			    		  st1.setString(2,str8); 
			    		  st1.setString(3,str2);
			    		  st1.setString(4,str3);
			    		  st1.setString(5,str4);
			    		  st1.setString(6,str5);
			    		  st1.executeUpdate();
			    		  pw.println("success");	    	
		}
	catch(Exception e)
		{
		pw.println(e.getMessage());
		
		
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
