

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class starttest
 */
@WebServlet("/starttest")
public class starttest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public starttest() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter pw=response.getWriter();
		
		try
		{String st="";
			String str=request.getParameter("id");
		String str1=request.getParameter("subject");
		String str2=request.getParameter("teacher");
		String str3=request.getParameter("topic");
		Class.forName("com.mysql.jdbc.Driver");
		Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/evaluator?user=root&password=adminadmin");	
		 String str4="Select distinct(id) from teacher where name='"+str2+"'";
		 PreparedStatement st3=cn.prepareStatement(str4);
		  ResultSet rs2=st3.executeQuery();
		  while(rs2.next()){
		    	st=rs2.getString(1);
		    }
		  
		String str5="select * from qa where studentid='"+str+"'&&subject='"+str1+"'&&teacherid='"+st+"'&&topic='"+str3+"'";
	PreparedStatement st2=cn.prepareStatement(str5);
	  ResultSet rs1=st2.executeQuery();
	  if(rs1.next())
	  {
		  
		  pw.println("invalid");
	  }
	  else
	  {
 		String str6="select question from teacher where subject='"+str1+"'&&name='"+str2+"'&&topic='"+str3+"'";
		    		  PreparedStatement st1=cn.prepareStatement(str6);
		    		  ResultSet rs=st1.executeQuery();
		    		  String data="";
					  
					   while(rs.next()){
					  data=data+rs.getString(1)+"&"; }
					   
	pw.println(data);
	
		
	  }}
		catch(Exception e)
		{
		pw.println(e.getMessage());
		
		
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
