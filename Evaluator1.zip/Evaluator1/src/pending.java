

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class pending
 */
@WebServlet("/pending")
public class pending extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pending() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter pw=response.getWriter();

		
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/evaluator?user=root&password=adminadmin");	
		
		
			int i=1;
			   String str="select * from request where status='pending'";
			    PreparedStatement st=cn.prepareStatement(str);
			   ResultSet rs=st.executeQuery();
			  String data="<table> <tr> <td style=color:red>NAME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td style=color:red>ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td style=color:red>TYPE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td style=color:red>ACCEPT&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td style=color:red>REJECT&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>";
			  
			   while(rs.next()){
				   data=data+"<tr><td>"+rs.getString(1)+"</td><td ><span id='di"+i+"'></span>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td><input type='checkbox' name='but' id='b"+i+"'></td><td><input type='checkbox' name='but' id='bb"+i+"' value='Reject' ></td></tr>";
			   i=i+1;
			   }
			   data=data+"<tr><td><input type='button' value='Save' onclick='check1()'></td><td><span id='div22'></span></td></tr>";
			  // data=data+"<tr><td ><span id='vv2'></span></td></tr>";
			   data=data+"</table>";
			   
				pw.println(data);
		}
		catch(Exception e)
		{
			
			pw.println(e.getMessage());
		}
		
		
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
