

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class afteradmin
 */
@WebServlet("/afteradmin")
public class afteradmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public afteradmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter pw=response.getWriter();
		String a="",str6,str7,str8,str9;
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/evaluator?user=root&password=adminadmin");	
		String str1=request.getParameter("accept");
		String str2=request.getParameter("reject");
		int i,j=0;
		for(i=0;i<str1.length();i++)
		{
			if(str1.charAt(i)==';')
			{
				a=str1.substring(j,i);
				j=i+1;
				str6="select * from request where id='"+a+"'";
				 PreparedStatement st=cn.prepareStatement(str6);
		
				 ResultSet rs=st.executeQuery();
				
				str7="Insert into user values(?,?,?,?)";
			
	    		  PreparedStatement st1=cn.prepareStatement(str7);
	    
	    		
	    			
	    			 while(rs.next()){
	    				
	    		  st1.setString(1,rs.getString(1));
	    		
	    		  st1.setString(2,rs.getString(5)); 
	    		  st1.setString(3,rs.getString(2));
	    		  st1.setString(4,rs.getString(3));
	    	
	    			 }
	    			  st1.executeUpdate();
	    		
	    		  str8="Update request set status='accepted' where id='"+a+"'";
	    		  PreparedStatement st2=cn.prepareStatement(str8);
	    		  st2.executeUpdate();
			}
			
		}
		j=0;
		
		for(i=0;i<str2.length();i++)
		{
			if(str2.charAt(i)==';')
			{
				a=str2.substring(j,i);
				j=i+1;
			
	    		  str9="Update request set status='rejected' where id='"+a+"'";
	    		  PreparedStatement st4=cn.prepareStatement(str9);
	    		  st4.executeUpdate();
			}
			
		}
	}
		catch(Exception e)
		{
			
			pw.println(e.getMessage());
		}
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
