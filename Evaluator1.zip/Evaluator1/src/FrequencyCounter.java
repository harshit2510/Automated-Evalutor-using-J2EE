    /**
     *This code is to create an Word-Frequency Counter
     *@author Dinesh
     *@version 0.1
     */
    import java.io.*;
    import java.util.*;
    class FrequencyCounter {
        public static void main(String[] args) {
            //System.out.println("Enter the file path to analyse:");
            Scanner scan = new Scanner(System.in);
           /* String path = "A:/matrix/";//Files present in this path will be analysed to count frequency
            File directory = new File(path);
            File[] listOfFiles = directory.listFiles();//To get the list of file-names found at the "directoy"
            BufferedReader br = null;*/
            String words[] = null;
            String line;
            String files;
            Map<String, Integer> wordCount = new HashMap<String, Integer>();     //Creates an Hash Map for storing the words and its count
           /* for (File file : listOfFiles) { 
                if (file.isFile()) {
                    files = file.getName();*/
                    try {
                    /*    if (files.endsWith(".txt") || files.endsWith(".TXT")) {  //Checks whether an file is an text file 
                            br = new BufferedReader(new FileReader(files));      //creates an Buffered Reader to read the contents of the file
                            while ((line = br.readLine()) != null) {
                                line = line.toLowerCase();*/	
            line="This is a string. This is not just a word but a complete paragraph of multiple sentences.";
                                words = line.split("\\s+");                      //Splits the words with "space" as an delimeter 
                            
                        
                        
                        for (String read : words) {
                            Integer freq = wordCount.get(read);
                            wordCount.put(read, (freq == null) ? 1 : freq + 1); //For Each word the count will be incremented in the Hashmap
                        }
                    } catch (NullPointerException e) {
                        System.out.println("I could'nt read your files:" + e);
                    }
                
                System.out.println(wordCount.size() + " distinct words:");     //Prints the Number of Distinct words found in the files read
                System.out.println(wordCount);                                 //Prints the Word and its occurrence
            }
        }
    