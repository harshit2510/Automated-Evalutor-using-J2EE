

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class show
 */
@WebServlet("/show")
public class show extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public show() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter pw=response.getWriter();

		
		try
		{
			String str1=request.getParameter("id");
			Class.forName("com.mysql.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/evaluator?user=root&password=adminadmin");	
		
		
			
			   String str="select distinct(studentid) from qa where teacherid='"+str1+"'";
			
			    PreparedStatement st=cn.prepareStatement(str);
			   ResultSet rs=st.executeQuery();
			   
			  String data="<table><tr><td><font size='4' color='red'>Student ID</font></td><td>             </td><td><font size='4' color='red'>Student Name</font></td><td>             </td><td><font size='4' color='red'>Topic</font></td></tr>";
			  
			   while(rs.next()){
				   String data1="select distinct(name) from qa where studentid='"+rs.getString(1)+"'";
				   
				   PreparedStatement st1=cn.prepareStatement(data1);
				   ResultSet rs1=st1.executeQuery();
				   while(rs1.next())
				   {
					   String str2="select distinct(topic) from qa where teacherid='"+str1+"'&&studentid='"+rs.getString(1)+"'";
					   PreparedStatement st2=cn.prepareStatement(str2);
					   ResultSet rs2=st2.executeQuery();
					   
			         while(rs2.next())
			         {
			        	 
						  
			        	 data=data+"<tr><td>"+rs.getString(1)+"</td><td>               </td><td>"+rs1.getString(1)+"</td><td>               </td><td>"+rs2.getString(1)+"</td></tr>"; 
			        	 
						   
			         }
				   }
			   }
			   
			   data=data+"</table>";
				   
				pw.println(data);
			  
			    		
			    		
			    		
			    		
			    		
			    		
			    	}
			    		
			    	
			    	
			    	
			    	
			    
	
		catch(Exception e)
		{
			
			pw.println(e.getMessage());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
