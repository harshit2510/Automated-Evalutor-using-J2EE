
import java.sql.*;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class requested
 */
@WebServlet("/requested")
public class requested extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public requested() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		int f=0;
		try
		{
			String str1=request.getParameter("id");
			
			String str2=request.getParameter("name");
			String str3=request.getParameter("type");
			String str5=request.getParameter("pass");
			String str4="pending";
			Class.forName("com.mysql.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/evaluator?user=root&password=adminadmin");	
		
		              String str7="Select * from request";
		              PreparedStatement st=cn.prepareStatement(str7);
		           ResultSet rs= st.executeQuery();
		           while(rs.next())
		           {
		        	   if(rs.getString(1)==str1)
		        	   {
		        		   f=1;
		        		   
		        		   
		        		   
		        		   
		        	   }
		        		   
		        	   
		        	   
		           }
			if(f==0)
			{
			    
			    		String str6="Insert into request values(?,?,?,?,?)";
			    		  PreparedStatement st1=cn.prepareStatement(str6);
			    		  st1.setString(1,str1);
			    		  st1.setString(2,str2); 
			    		  st1.setString(3,str3);
			    		  st1.setString(4,str4);
			    		  st1.setString(5,str5);
			    		  st1.executeUpdate();
			    		  pw.println("success");
			    		  
			    		  
			    	
			    	
			    	
			    	
			    	
			    	
			    
			   
			
			
			
			
			
			
			
			
			
			}
			
			
		}
	catch(Exception e)
		{
pw.println(e.getMessage());
		
		
		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
