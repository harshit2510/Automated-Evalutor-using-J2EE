

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class set_score
 */
@WebServlet("/set_score")
public class set_score extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public set_score() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw=response.getWriter();
		try
		{
			
			String str=request.getParameter("id");
			String str1=request.getParameter("subject");
			String str2=request.getParameter("teacher");
			String str3=request.getParameter("topic");
			String str4="";
			String y="";
			Class.forName("com.mysql.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/evaluator?user=root&password=adminadmin");	

	          String str7="Select distinct(id) from teacher where name='"+str2+"'";
	          PreparedStatement st=cn.prepareStatement(str7);
	          ResultSet rs=st.executeQuery();
	          while(rs.next()){
			    	str4=rs.getString(1);
			    }
			String x="select sum(marks) from qa where studentid='"+str+"'&&subject='"+str1+"'&&topic='"+str3+"'&&teacherid='"+str4+"'";
			  PreparedStatement st1=cn.prepareStatement(x);
			    ResultSet rs1=st1.executeQuery();
			while(rs1.next())
			{
	        y=rs1.getString(1);	
			}
			double yy=Double.parseDouble(y);
			String str10="Insert into score values(?,?,?,?,"+yy+")";
			PreparedStatement st2=cn.prepareStatement(str10);
			st2.setString(1,str);
			st2.setString(2,str1); 

			st2.setString(3,str4);
			st2.setString(4,str3);
			st2.executeUpdate();
		//	pw.println(yy);
		
		}
	
		 catch(Exception e)
      {
    		
			 pw.println(e.getMessage());
      }
	}/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
