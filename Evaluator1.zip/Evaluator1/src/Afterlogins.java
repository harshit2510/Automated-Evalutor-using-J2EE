

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Afterlogins
 */
@WebServlet("/Afterlogins")
public class Afterlogins extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Afterlogins() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();

		
		try
		{
			String str1=request.getParameter("id");
			String str2=request.getParameter("pass");
			String str3=request.getParameter("type");
		
			Class.forName("com.mysql.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/evaluator?user=root&password=adminadmin");	
		
		
			
			   String str="Select * from user";
			    PreparedStatement st=cn.prepareStatement(str);
			    ResultSet rs=st.executeQuery();
			   
		int f=0;
		 while(rs.next()){
		    	if(str1.equals(rs.getString(1))&&str2.equals(rs.getString(2))&&str3.equals(rs.getString(4)))
		    	{
		    		f=1;
		    		HttpSession hs=request.getSession();
		    		hs.setAttribute("id",str1);
		    		pw.println("success");
		    		break;
		    	}
			
		}
		 if(f==0)
			 pw.println("failure");
		}
		 catch(Exception e)
		 {
			 pw.println(e.getMessage());
		 }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
